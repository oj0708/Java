package assign1;
/*
 * File Name:Doctor.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/09/22
 */
public class Doctor {

	//field variables
	private String firstName;
	private String lastName;
	private String specialty;

	//default constructor
	public Doctor() {}
	//Parameterized constructor
	public Doctor(String firstName, String lastName, String specialty) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.specialty = specialty;
	}
	//overwrite toString()
	@Override
	public String toString() {
		return String.format("%s, %s, %s",getFirstName(),getLastName(),getSpecialty());
	}
	//getter for first name
	public String getFirstName() {
		return this.firstName;
	}
	//setter for first name
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	//getter for last name
	public String getLastName() {
		return this.lastName;
	}
	//setter for last name
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	//getter for specialty
	public String getSpecialty() {
		return this.specialty;
	}
	//setter for specialty
	public void setSpecialty(String specialty){
		this.specialty = specialty;
	}

}
