package assign1;
/*
 * File Name:MedicalClinicTester.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/09/22
 */
public class MedicalClinicTester {
	public static void main(String[] args) {
		MedicalClinic open = new MedicalClinic();
		open.menu();


	}
}
