package assign1;
/*
 * File Name:OurDate.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/09/22
 */
public class OurDate {
	//field variables
	private int day;
	private int month;
	private int year;
	//default constructor
	public OurDate() {}
	//Parameterized constructor
	public OurDate(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}
	//getter for day
	public int getDay() {
		return day;
	}
	//setter for day
	public void setDay(int day) {
		this.day=day; 
	}
	//getter for month
	public int getMonth() {
		return month;
	}
	//setter for month
	public void setMonth(int month) {
		this.month = month;
	}
	//getter for year
	public int getYear() {
		return year;
	}
	//setter for year
	public void setYear(int year) {
		this.year = year;
	}
	//overwrite toString()
	@Override
	public String toString() {
		return String.format("day=%s, month=%s, year=%s",getDay(),getMonth(),getYear());
	}

}
