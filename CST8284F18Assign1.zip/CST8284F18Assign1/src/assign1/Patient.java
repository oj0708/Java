package assign1;
/*
 * File Name:Patient.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/09/22
 */
public class Patient {

	//field variables
	private String firstName;
	private String lastName;
	private int healthCardNumber;
	private OurDate birthDate;
	private Appointment appointment;
	//default Constructor
	public Patient() {}
	//Parameterized constructor
	public Patient(String firstName, String lastName, int healthCardNumber, OurDate birthDate) {
		this.firstName=firstName;
		this.lastName=lastName;
		this.healthCardNumber=healthCardNumber;
		this.birthDate=birthDate;
	}
	//overwrite toString()
	@Override
	public String toString() {
		return String.format("Patient[firstName=%s, lastName=%s, BirthDate=day=%s, month=%s, year=%s, healthCardNumber=%s]",
				getFirstName(),getLastName(),getBirthDate().getDay(),
				getBirthDate().getMonth(),getBirthDate().getYear(),getHealthCardNumber());
	}

	//getter for first name
	public String getFirstName() {
		return this.firstName;
	}
	//setter for first name
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	//getter for last name
	public String getLastName() {
		return this.lastName;
	}
	//setter for last name
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	//getter for health card number
	public int getHealthCardNumber() {
		return this.healthCardNumber;
	}
	//setter for health card number
	public void setHealthCardNumber(int healthCardNumber){
		this.healthCardNumber = healthCardNumber;
	}
	//getter for birth date
	public OurDate getBirthDate() {
		return this.birthDate;
	}
	//setter for birth date
	public void setBirthDate(OurDate birthDate) {
		this.birthDate=birthDate;
	}
	//getter for appointment
	public Appointment getAppointment() {
		return this.appointment;
	}
	//setter for appointment
	public void setAppointment(Appointment appointment){
		this.appointment = appointment;
	}
}
