package assign1;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
/*
 * File Name:MedicalClinic.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/09/22
 */

public class MedicalClinic{

	//create arrays
	private Appointment[] appointments;
	private Patient[] patients;
	private Doctor[] doctors;

	//Array sizes
	private static final int MAXAPPOINTMENTS=10;
	private static final int MAXPATIENTS=10;
	private static final int MAXDOCTORS=5;


	/*create counters for tracking Appointments/Patients/Doctors*/
	private static int numberAppointments;
	private static int numberPatients;
	private static int numberDoctors;

	// create scanner in for user input
	private Scanner in= new Scanner(System.in);

	//default constructor
	public MedicalClinic(){

		//create memory space for three arrays
		appointments = new Appointment[MAXAPPOINTMENTS];
		patients = new Patient[MAXPATIENTS];
		doctors = new Doctor[MAXDOCTORS];

		//set counters to 0
		numberAppointments =0;
		numberPatients = 0;
		numberDoctors = 0;

		/*some random data to create those five doctors to make this work*/		
		doctors[0] = new Doctor("Micheal", "Robbins","Chiropractor");
		doctors[1] = new Doctor("David", "Warkentin","Chiropractor");
		doctors[2] = new Doctor("Tassos", "Irinakis","Periodontist");
		doctors[3] = new Doctor("Nina", "Gillmore","Dentist");
		doctors[4] = new Doctor("Bruce", "Hoffman","Psychologist");


		//set the number of doctors manually
		numberDoctors = 5;

	}
	/*menu options for user choose*/
	public void menu(){
		int choice=4;

		do {
			//display the menu option
			System.out.println("\nPlease make a choice: ");
			System.out.println("1.  Enter a new patient");
			System.out.println("2.  Make an appointment for a patient");
			System.out.println("3.  List all appointment");
			System.out.println("4.  Quit");
			//choice from user input
			choice = in.nextInt();

			switch (choice) {
			case 1:
				addPatient();//add patients info, details see addPatient()

				break;
			case 2:
				addAppointment();//add appointment info, details see addAppointment()

				break;
			case 3:
				listAppointment();//print appointments info, details see listAppointment()
				break;

			}

		}while (choice != 4);


		System.out.println("\nGood Bye");
		//close user input
		in.close();
	}

	/*method for adding patients required informations*/

	public void addPatient() {
		//local variables

		String birthDateString;
		boolean foundPatient = false;
		boolean isValidDate=true;
		int day,month,year;

		//Verify if reached the limited patients per day
		if(numberPatients==MAXPATIENTS) {
			System.out.println("No more patients for today!");
		}

		//if not go ahead continue the data input process
		else {

			patients[numberPatients]=new Patient();
			//start enter details for new patients
			System.out.print("Enter first name:");
			patients[numberPatients].setFirstName(in.next());
			System.out.print("Enter last name:");
			patients[numberPatients].setLastName(in.next());
			System.out.print("Enter Health card number:");
			patients[numberPatients].setHealthCardNumber(in.nextInt());
			//verify the health card number to see if the patient already exist in the system
			for(int i=0;i<numberPatients;i++) {
				if(patients[i].getHealthCardNumber()==patients[numberPatients].getHealthCardNumber()) {
					System.out.println(patients[numberPatients].getFirstName()+" "+patients[numberPatients].getLastName()+" is already in the system.");
					foundPatient = true;
					i = numberPatients;
				}
			}

			//if not found in the system, keep entering the birth date information
			if(!foundPatient) {
				do {
					/*Verify for range of day/month/year to make sure there are no typo or mistakes*/
					System.out.print("Enter birth date DDMMYYYY:");
					birthDateString = in.next();
					day = Integer.parseInt(birthDateString.substring(0, 2));
					month = Integer.parseInt(birthDateString.substring(2, 4));
					year = Integer.parseInt(birthDateString.substring(4));
					GregorianCalendar cl = new GregorianCalendar(year, month - 1, 1);
					//verify the year in range 1900-2018
					if(year<1900 || year >2018) {
						isValidDate=false;
						System.out.println("Year out of range.Please enter correct birth date again!");
					}//verify the month in 1-12 range
					else if(month<1 || month>12) {
						isValidDate=false;
						System.out.println("Month out of range.Please enter correct birth date again!");
					}//verify day range of the month user entered
					else if(day < cl.getActualMinimum(Calendar.DAY_OF_MONTH)
							|| day > cl.getActualMaximum(Calendar.DAY_OF_MONTH)) {
						isValidDate=false;
						System.out.println("Day out of range.Please enter correct birth date again!");
					}
					else {isValidDate=true;}


				}while(!isValidDate);
				//add date info into the current patient array
				patients[numberPatients].setBirthDate(new OurDate(day,month,year));			
				//patient counter +1
				numberPatients ++;

			}
		}

	}//end of addPatient() method

	public void addAppointment() {
		int choice, day, month, year;
		//verify the number of appointments
		if(numberAppointments==MAXAPPOINTMENTS) {
			System.out.println("Appointments full today!");
			return;
		}

		//if not go ahead continue the data input process
		else {

			System.out.print("Enter health card number:");

			int healthCardNumber = in.nextInt();

			//list patient information
			int bookingPatient=0;
			/*Verify if patient already in system. if found patient, keep booking appointment, otherwise
			 * return to the menu to create patient first. */
			boolean isFound = false;
			for(int i=0; i<numberPatients;i++ ) {
				if(healthCardNumber-patients[i].getHealthCardNumber()==0) {
					System.out.println(patients[i]);
					bookingPatient=i;
					isFound = true;
				}
			}		
			if(!isFound) {
				System.out.println("Patient no in file,please go to 1 add patient first");
				return;
			}
			System.out.println();

			boolean isDoctorTaken=false;
			//list doctors by names
			do {
				for(int i=0;i<numberDoctors;i++) {

					System.out.println((i+1)+" "+doctors[i].getFirstName()+" "+doctors[i].getLastName());
				}		
				//select the doctor 
				System.out.print("Enter number for doctor selection:");
				choice=in.nextInt();
				//verify chosen doctor if already taken
				for(int i =0; i<numberAppointments;i++) {
					if(doctors[choice-1].getFirstName()==appointments[i].getDoctor().getFirstName() && doctors[choice-1].getLastName()==appointments[i].getDoctor().getLastName()) {
						isDoctorTaken=true;
					}else {
						isDoctorTaken=false;
					}
				}
				if(isDoctorTaken) {
					System.out.println("Doctor already taken,please choose another doctor for your appointment.");
				}
			}while(isDoctorTaken);	

			boolean isDateTaken=false;
			do{
				boolean isValidDate= true;

				do {
					/*verify the date entry in the proper ranges for day/month/year*/
					System.out.print("Enter desired appointment date DDMMYYYY:");
					String appDateString = in.next();
					day = Integer.parseInt(appDateString.substring(0, 2));
					month = Integer.parseInt(appDateString.substring(2, 4));
					year = Integer.parseInt(appDateString.substring(4));

					GregorianCalendar cl = new GregorianCalendar(year, month - 1, 1);
					//verify the year in range 1900-2018
					if(year<1900 || year >2018) {
						isValidDate=false;
						System.out.println("Year out of range.Please enter correct date again!");
					}//verify the month in 1-12 range
					else if(month<1 || month>12) {
						isValidDate=false;
						System.out.println("Month out of range.Please enter correct date again!");
					}//verify day range of the month user entered
					else if(day < cl.getActualMinimum(Calendar.DAY_OF_MONTH)
							|| day > cl.getActualMaximum(Calendar.DAY_OF_MONTH)) {
						isValidDate=false;
						System.out.println("Day out of range.Please enter correct date again!");
					}
					else {isValidDate=true;}


				}while(!isValidDate);

				/*Verify if appointment date for patient is taken already*/
				for(int i=0;i<numberAppointments;i++) {
					if(day==appointments[i].getAppointmentDate().getDay() 
							&& month==appointments[i].getAppointmentDate().getMonth() 
							&& year==appointments[i].getAppointmentDate().getYear()) {

						isDateTaken=true;
					}else {
						isDateTaken=false;
					}			
				}
				if(isDateTaken) {
					System.out.println("Date already taken, please pick another date for your appointment.");
				}
			}while(isDateTaken);

			//make an appointment and set the data for the appointment
			appointments[numberAppointments] = new Appointment();
			appointments[numberAppointments].setDoctor(doctors[choice-1]);
			appointments[numberAppointments].setAppointmentDate(new OurDate(day,month,year));
			appointments[numberAppointments].setPatient(patients[bookingPatient]);
			//appointment counter +1
			numberAppointments ++;
		}
	}//end of addAppointment() method

	/*method for print the list of created appointments*/

	public void listAppointment() {
		//check if there are appointments to print
		if(numberAppointments == 0) {
			System.out.println("No upcoming appointments");
			return;
		}
		else {//print all added appointments 
			for(int i=0;i<numberAppointments; i++) {
				System.out.println(appointments[i].toString());
			}
		}
	}//end of listAppointment()
}//end of class
