package assign1;
/*
 * File Name:Appointment.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/09/22
 */
public class Appointment {

	private Doctor doctor = new Doctor();//create doctor object
	private Patient patient = new Patient();//create patient object
	private OurDate date = new OurDate();//create date object

	//default constructor
	public Appointment() {}
	// getter for Doctor 
	public Doctor getDoctor() {
		return this.doctor;
	}
	//setter for Doctor
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	//getter for patient
	public Patient getPatient() {
		return this.patient;
	}
	//setter for patient
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	//getter for appointment
	public OurDate getAppointmentDate() {
		return date;
	}
	//setter for appointment
	public void setAppointmentDate(OurDate aDate) {
		this.date = aDate;
	}
	//overwrite toString()
	@Override
	public String toString() {
		return String.format("Appointment[appointment=%s,doctor=%s,patient=%s]",getAppointmentDate(),getDoctor(),getPatient());
	}
}
