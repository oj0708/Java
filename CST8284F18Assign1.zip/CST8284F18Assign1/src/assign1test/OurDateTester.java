package assign1test;
/*
 * File Name:OurDateTester.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/09/22
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import assign1.OurDate;

class OurDateTester {

	OurDate date;
	/*
	 * clean after each test  finished
	 */

	@AfterEach
	public void testAfterEach() {

		System.out.println("Test done");
		date = null;
	}

	/*
	 * clean testing environment after all tests finished
	 */
	@AfterAll
	public static void tearDownAfterAll() {

		System.out.println("All Test Done."
				+ "\nThanks for using JUnit!"
				+"\nAssign1 OurDate COnstructor Tester created by \nQiang Pan \n040920667");
	}

	/*
	 * set up testing environment for all tests
	 */
	@BeforeAll
	public static void setUpBeforeAll() {
		System.out.println("Welcome to OurDate Tester \nLet's start");
	}

	/*
	 * set up before each test
	 */
	@BeforeEach
	void setUpBeforeEach(){
		date = new OurDate();
		System.out.println("Testing........");
	}

	/*
	 * test year value of default constructor
	 */
	@Test
	void testDefaultConstructorForYear() {

		assertEquals(0,date.getYear(),"Default constructor test year fail");
	}

	/*
	 * test month value of default constructor
	 */
	@Test
	void testDefaultConstructorForMonth() {


		assertEquals(0,date.getMonth(),"Default constructor test month fail");
	}

	/*
	 * test day value of default constructor
	 */
	@Test
	void testDefaultConstructorForDay() {


		assertEquals(0,date.getDay(),"Default constructor test day fail");
	}

	/*
	 * test year value of overloaded constructor
	 */
	@Test
	void testOverLoadDefaultConstructorForYear() {
		date = new OurDate(20,2,2000);
		assertEquals(2000,date.getYear(),"OverLoad constructor test year fail");
	}

	/*
	 * test month value of overloaded constructor
	 */
	@Test
	void testOverLoadDefaultConstructorForMonth() {
		date = new OurDate(20,2,2000);
		assertEquals(2,date.getMonth(),"OverLoad constructor test month fail");
	}

	/*
	 * test day value of overloaded constructor
	 */
	@Test
	void testOverLoadDefaultConstructorForDay() {
		date = new OurDate(20,2,2000);
		assertEquals(20,date.getDay(),"OverLoad constructor test day fail");
	}






}
