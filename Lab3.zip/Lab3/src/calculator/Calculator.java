package calculator;

public class Calculator {

		private double accumulator;
		public Calculator(double accumulator) {
			this.accumulator=accumulator;
		}
		public double add(double x, double y ) {
			this.accumulator=x+y;
			return accumulator;
		}
		double sqrt(double x) {
			this.accumulator=Math.sqrt(x);
			return this.accumulator;
		}
		
}
