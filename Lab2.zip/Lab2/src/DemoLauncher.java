
public class DemoLauncher {
	public static void main(String[] args) {

		ArrayDemo demo = new ArrayDemo();

		demo.demoTask1();
		demo.demoTask2();
		demo.demoTask3();
		demo.demoTask4();

	}
}