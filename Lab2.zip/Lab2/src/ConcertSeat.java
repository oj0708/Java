public class ConcertSeat {
	private int row;
	private int seatNumber;
	public ConcertSeat() {
		row = 0;
		seatNumber = 0;
	}
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	@Override
	public String toString() {
		return "Seat row: " + row + ", Number:" +
				seatNumber +" ";
	} 

}
