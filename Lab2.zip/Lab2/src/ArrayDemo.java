public class ArrayDemo {
	public void demoTask1(){
		System.out.println("Demonstrate Task 1");

		int[] singleDimensionArray = null; // note that numbers references nothing (null) initially
		singleDimensionArray = new int[5]; // a reference to an Array object containing int values is assigned

		System.out.println("Array of primitives before assigning values");
		// TODO: enhance for loop to print the values in the array elements on one line separated by spaces
		for(int i =0; i < singleDimensionArray.length; i ++) {
			System.out.print(singleDimensionArray[i]);
			System.out.print(" ");
		}
		// TODO: loop to assign values 1 to 5 into the array elements
		for(int i =0; i < singleDimensionArray.length; i ++) {
			singleDimensionArray[i] = i;
		}

		System.out.println("\nArray of primitives after assigning values");
		// TODO: loop to again print the values on one line separated by spaces
		for(int i =0; i < singleDimensionArray.length; i ++) {
			System.out.print(singleDimensionArray[i]);
			System.out.print(" ");
			// TODO: DRAW MEMORY MAP for int[] singleDimensionArray = new int[5]; at this point
		}
	}

	public void demoTask2(){
		System.out.print("\n\nDemonstrate Task 2");
		int[][]twoDimensionArray = new int[3][5];

		System.out.println("\n2 Dimension Array of primitives before assigning values");
		// TODO: loop to print the values in three rows and two columns, with each array element separated by a space
		for(int i =0; i < twoDimensionArray.length; i ++) {
			for(int j = 0; j < twoDimensionArray[i].length;j++) {
				System.out.print(twoDimensionArray[i][j]);
				System.out.print(" ");
			}System.out.println(" ");
		}


		// TODO: loop to initialize each array element twoDimensionArray, each with weights of 1,2,3,4,5 2,4,6,8,10 3,6,9,12,15
		for(int i =0; i < twoDimensionArray.length; i ++) {
			for(int j = 0; j < twoDimensionArray[i].length;j++) {
				twoDimensionArray[i][j] = (i+1)*(j+1);
			}
		}
		System.out.println("\n2 Dimension Array of primitives after assigning values");
		// TODO: loop to print the values in three rows and two columns, with each array element separated by a space
		for(int i =0; i < twoDimensionArray.length; i ++) {
			for(int j = 0; j < twoDimensionArray[i].length;j++) {
				System.out.print(twoDimensionArray[i][j]);
				System.out.print(" ");
			}System.out.println(" ");
		}
		// TODO: DRAW MEMORY MAP for in [][]twoDimensionArray = new twoDimensionArray[5][5]; at this point
	}
	public void demoTask3(){
		System.out.println("\nDemonstrate Task 3");

		ConcertSeat[] seat = new ConcertSeat[5];

		//3a
		System.out.println("Array of references before assigning references - toString() not explicitly defined in ConcertSeat");
		// TODO: loop to print the reference value within each array element on separate lines, use the reference name as the argument to print()
		for(int i = 0; i < seat.length; i++) {
			System.out.println(seat);
		}
		
		//3b
		System.out.println("\nArray of references before assigning references - toString() explicitly defined in ConcertSeat");
		// TODO: loop to print the reference value within each array element on separate lines, invoke the toString() method
		for(int i = 0; i < seat.length; i++) {
			System.out.println(seat.toString());
		}
		//3c
		// TODO: loop to instantiate each array element with a ConcertSeat reference to aobject
		// TODO: invoke the setRow() and setSeatNumber() method to assign row to 1 and seats numbers to 1, 2, 3, 4, 5
		System.out.println("\nArray of references after assigning references - use toString()");
		// TODO: loop to print the each referenced objects seat number separated by a space
		for(int i = 0; i < seat.length; i++) {
			seat[i]= new ConcertSeat();
			seat[i].setRow(1);
			seat[i].setSeatNumber(i+1);
			System.out.println(seat[i].toString());
		}

		// TODO: DRAW MEMORY MAP for ConcertSeat[] seat = new ConcertSeat[5]; at this point
	}
	public void demoTask4(){
		System.out.println("\nDemonstrate Task 4");

		ConcertSeat[][] seats = new ConcertSeat[5][5];
		//4a
		// TODO: loop to instantiate each array element with a ConcertSeat reference to an object
		//TODO: assign each reference rows and columns as specified in the lab writeup

		for(int i=0;i<seats.length;i++) {
			for(int j=0;j<seats[i].length;j++) {
				seats[i][j]=new ConcertSeat();
				seats[i][j].setRow(i+1);
				seats[i][j].setSeatNumber(j+1);
			}
		}
		//TODO: print out the 2-D array in rows and columns (see sample output in lab writeup)
		for(int i=0;i<seats.length;i++){

			for(int j=0;j<seats[i].length;j++){

				System.out.print(seats[i][j].toString());

			}System.out.println();
		}

		// TODO: DRAW MEMORY MAP for int[][] numbers = new int[5][5]; at this point

		//4b
		//THIS CODE WILL THROW AN EXCEPTION WHEN THE TASKS ARE COMPLETED
		System.out.println("\n2D Array of references after changing (set to null) an element at position (2, 4)");
		// TODO: assign a value of null to element (2, 4)
		// TODO: use nested loops to display the array elements,

		for(int i=0;i<seats.length;i++){

			for(int j=0;j<seats[i].length;j++){
				if (i==2&&j==4) {
					seats[i][j]=null;
				}

				System.out.print(seats[i][j].toString());

			}System.out.println();
		}
	}

}




