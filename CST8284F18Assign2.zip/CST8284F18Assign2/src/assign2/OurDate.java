package assign2;
/*
 * File Name:OurDate.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/10/22
 */


//import build-in Calendar method from java library
import java.util.Calendar;

public class OurDate {

	//Initialize calendar for the Calendar method
	private static final Calendar CALENDAR = Calendar.getInstance();

	//define three field integer variables day/month/year
	private int day;
	private int month;
	private int year;


	/*
	 * default constructor of OurDate
	 */
	public OurDate() {
		//chain the constructor
		this(CALENDAR.get(Calendar.DATE),CALENDAR.get(Calendar.MONTH)+1,CALENDAR.get(Calendar.YEAR));
	}
	/*
	 * parameter constructor of OurDate
	 */
	public OurDate(int day, int month, int year) {

		//INVOKE SETTERS INSTEAD OF ASSIGNING VALUES 
		setDay(day);
		setMonth(month);
		setYear(year);
	}
	/*
	 * getter of day for the OurDate class
	 */
	public int getDay() {
		return day;
	}
	/*
	 * setter of day for the OurDate class
	 */
	private void setDay(int day) {
		this.day = day;
	}
	/*
	 *getter of month for the OurDate class 
	 */
	public int getMonth() {
		return month;
	}
	/*
	 *setter of month for the OurDate class 
	 */
	private void setMonth(int month) {
		this.month = month;
	}
	/*
	 *getter of year for the OurDate class
	 */
	public int getYear() {
		return year;
	}

	/*
	 *setter of year for the OurDate class
	 */
	private void setYear(int year) {
		this.year = year;
	}

	/*
	 *toString() override for the OurDate class
	 */
	@Override
	public String toString() {
		return day+"/"+month+"/"+year;
	}
	/* 
	 * hashCode() override for the OurDate class
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + day;
		result = prime * result + month;
		result = prime * result + year;
		return result;
	}
	/*
	 * equals() override for the OurDate class
	 */
	@Override
	public boolean equals(Object obj) {

		if (obj == null)
			return false;

		if (!(obj instanceof OurDate))
			return false;

		OurDate d = (OurDate) obj;

		return this.getDay()==d.getDay() && this.getMonth()==d.getMonth() && this.getYear()==d.getYear();
	}

}//end of class
