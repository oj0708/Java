package assign2;
/*
 * File Name:Doctor.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/10/22
 */

public class Doctor {

	//define three String variables for Doctor class





	private String firstName;
	private String lastName;
	private String specialty;

	/*
	 * default constructor of Doctor class
	 */
	public Doctor() {
		//chain the constructor
		this("unknown","unknown","unknown");
	}

	/*
	 * Parameter Constructor of Doctor class
	 */
	public Doctor(String firstName, String lastName, String specialty) {

		//INVOKE SETTERS 
		setFirstName(firstName);
		setLastName(lastName);
		setSpecialty(specialty);
	}



	/*
	 * getter of the firstName for Doctor Class
	 */
	public String getFirstName() {
		return firstName;
	}



	/*
	 * setter of firstName for Doctor Class
	 */
	private void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	/*
	 * getter of lastName for Doctor Class
	 */
	public String getLastName() {
		return lastName;
	}




	/*
	 * setter of lastName for Doctor Class
	 */
	private void setLastName(String lastName) {
		this.lastName = lastName;
	}



	/*
	 * getter of specialty for Doctor Class
	 */
	public String getSpecialty() {
		return specialty;
	}



	/*
	 * setter of specialty for Doctor Class
	 */
	private void setSpecialty(String specialty) {
		this.specialty = specialty;
	}



	/* 
	 * hashcode() override for Doctor class
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((specialty == null) ? 0 : specialty.hashCode());
		return result;
	}



	/* 
	 * equals() override for Doctor class
	 */
	@Override
	public boolean equals(Object obj) {

		if(obj== null)
			return false;

		if(!(obj instanceof Doctor))
			return false;
		Doctor d = (Doctor) obj;

		return this.getFirstName().equals(d.getFirstName()) && this.getLastName().equals(d.getLastName()) && this.getSpecialty().equals(d.getSpecialty());
	}

	/* 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return lastName + " "+ firstName + " "+ specialty;
	}



}//end of class
