package assign2;
/*
 * File Name:Appointment.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/10/22
 */

public class Appointment {

	//define three field variables doctor/patient/appointment for the Appointment class
	private Doctor doctor;
	private Patient patient;
	private OurDate appointmentDate;

	/*
	 *default constructor for Appointment class
	 */
	public Appointment() {
		//CHAIN THE CONSTRUCTOR
		this(new Patient(), new Doctor(), new OurDate());
	}


	/*
	 * parameter constructor for Appointment class
	 */
	public Appointment(Patient patient, Doctor doctor,  OurDate appointmentDate) {

		//INVOKE SETTERS INSTEAD OF ASSIGNING VALUES 
		setPatient(patient);
		setDoctor(doctor);
		setAppointmentDate(appointmentDate);
	}


	/*
	 *getter for the doctor of Doctor class
	 */
	public Doctor getDoctor() {
		return doctor;
	}
	/*
	 * setter for the doctor of Doctor class
	 */
	private void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	/*
	 * getter for the patient of Patient class
	 */
	public Patient getPatient() {
		return patient;
	}
	/*
	 * setter for the patient of Patient class
	 */
	private void setPatient(Patient patient) {
		this.patient = patient;
	}
	/*
	 * getter for the doctor of Doctor class
	 */
	public OurDate getAppointmentDate() {
		return appointmentDate;
	}
	/*
	 * setter for the appointment of OurDate class
	 */
	private void setAppointmentDate(OurDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}


	/* 
	 * toString() override for Appointment class 
	 */
	@Override
	public String toString() {
		return "Appointment date: "+ appointmentDate.toString()+","+" Dr. "+doctor.getFirstName()+
				" "+doctor.getLastName()+", "+doctor.getSpecialty()+", "+patient.toString();
	}


	/* 
	 * hashCode() override for Appointment class
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((appointmentDate == null) ? 0 : appointmentDate.hashCode());
		result = prime * result + ((doctor == null) ? 0 : doctor.hashCode());
		result = prime * result + ((patient == null) ? 0 : patient.hashCode());
		return result;
	}


	/* 
	 * equals() override for Appointment class
	 */

	@Override
	public boolean equals(Object obj) {

		if (obj == null)
			return false;

		if (!(obj instanceof Appointment))
			return false;

		Appointment a = (Appointment) obj;

		return this.getAppointmentDate().equals(a.getAppointmentDate()) && this.getDoctor().equals(a.getDoctor()) && this.getPatient().equals(a.getPatient());
	}


}//end of class
