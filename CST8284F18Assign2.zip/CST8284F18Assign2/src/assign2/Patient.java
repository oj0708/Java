package assign2;
/*
 * File Name:Patient.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/10/22
 */
public class Patient {

	//field variables
	private String firstName;
	private String lastName;
	private int healthCardNumber;
	private OurDate birthDate;

	/*
	 *default constructor 
	 */
	public Patient() {
		//chain constructor
		this("unknown","unknown",1,new OurDate(1,1,1800));
	}

	/*
	 * parameter constructor
	 */
	public Patient(String firstName, String lastName, int healthCardNumber, OurDate birthDate) {

		//INVOKE SETTERS INSTEAD OF ASSIGNING VALUES 
		setFirstName(firstName);
		setLastName(lastName);
		setHealthCardNumber(healthCardNumber);
		setBirthDate(birthDate);
	}

	/*
	 * getter of firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/*
	 * setter of firstName
	 */
	private void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/*
	 * getter of lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/*
	 * setter of lastName
	 */
	private void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/*
	 * getter of healthCardNumber
	 */
	public int getHealthCardNumber() {
		return healthCardNumber;
	}

	/*
	 * setter of healthCardNumber
	 */
	private void setHealthCardNumber(int healthCardNumber) {
		this.healthCardNumber = healthCardNumber;
	}

	/*
	 * getter of bithDate
	 */
	public OurDate getBirthDate() {
		return birthDate;
	}

	/*
	 * setter of birthDate
	 */
	private void setBirthDate(OurDate birthDate) {
		this.birthDate = birthDate;
	}

	/*
	 * toString() override for Patient class
	 */
	@Override
	public String toString() {
		return lastName + ", "+ firstName + ", " + "Health Card Number: "+healthCardNumber +", dob: "+ birthDate.toString() ;
	}

	/* 
	 * hashCode() override for the Patient class
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((birthDate == null) ? 0 : birthDate.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + healthCardNumber;
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		return result;
	}

	/*
	 * equals() override for Patient class
	 */
	@Override
	public boolean equals(Object obj) {

		if (obj == null)
			return false;
		if (!(obj instanceof Patient))
			return false;

		Patient p = (Patient) obj;

		return this.getFirstName().equals(p.getFirstName()) && this.getLastName().equals(p.getLastName())
				&& this.getHealthCardNumber()==p.getHealthCardNumber() && this.getBirthDate().equals(p.getBirthDate());
	}


}//end of class
