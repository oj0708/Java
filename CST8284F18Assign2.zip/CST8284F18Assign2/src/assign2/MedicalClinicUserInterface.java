package assign2;
/*
 * File Name:MedicalClinicUserInterface.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/10/22
 */
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class MedicalClinicUserInterface {

	private static final int ADD_PATIENT = 1;
	private static final int ADD_APPOINTMENT = 2;
	private static final int CANCEL_APPOINTMENT = 3;
	private static final int LIST_APPOINTMENT = 4;
	private static final int QUIT = 5;

	private MedicalClinic clinic;
	private Scanner in = new Scanner(System.in);

	/*
	 * default constructor 
	 */
	public MedicalClinicUserInterface() {

		clinic = new MedicalClinic();
	}

	//the main method
	public static void main(String[] args) {

		MedicalClinicUserInterface run = new MedicalClinicUserInterface();
		run.menu();


	}

	/*menu options for user choose*/
	public void menu(){
		int choice=QUIT;

		do {
			//display the menu option
			System.out.println("\nPlease make a choice: ");
			System.out.println(ADD_PATIENT+" Enter a new patient");
			System.out.println(ADD_APPOINTMENT+" Make an appointment for a patient");
			System.out.println(CANCEL_APPOINTMENT+" Cancel an appointment for a patient");
			System.out.println(LIST_APPOINTMENT+" List all appointment");
			System.out.println(QUIT+" Quit");
			//choice from user input
			choice = in.nextInt();

			switch (choice) {
			case ADD_PATIENT:
				addPatient();//add patients info, details see addPatient()

				break;
			case ADD_APPOINTMENT:
				addAppointment();//add appointment info, details see addAppointment()

				break;
			case CANCEL_APPOINTMENT:
				cancelAppointment();//cancel a appointment 

				break;
			case LIST_APPOINTMENT:
				listAppointment();//print appointments info, details see listAppointment()

				break;

			case 9:

				System.out.println(""); 
				printPatient();//will printout the patient list when choose any numbers not listed above

				break;
			}

		}while (choice != QUIT);

		//close user input
		in.close();
	}
	/*
	 * addPatient() for system collecting and adding patient info into the patient ArrayList
	 * */
	public void addPatient() {

		//local variables
		boolean foundPatient=false; 
		boolean isValidDate=false;

		//verify patient number to see if reached the MAX number of the day
		if(clinic.getNumberPatients()==clinic.getMaxPatients()) {
			System.out.println("No more patients for today!");
			return;
		}else {

			//collecting patient info from user input
			System.out.print("Enter first name:");
			String fName=in.next();
			System.out.print("Enter last name:");
			String lName=in.next();
			System.out.println("");
			System.out.print("Enter health card number:");
			int hCard=in.nextInt();
			//verify the health card number to see if the patient already exist in the system
			for(int i=0;i<clinic.getNumberPatients();i++) {
				if(clinic.getPatients().get(i).getHealthCardNumber()==hCard) {
					System.out.println(fName+" "+lName+" is already in the system.");
					foundPatient = true;
					i = clinic.getNumberPatients();
				}
			}
			if(!foundPatient) {

				int day=0,month=0,year=0;

				do {

					/*Verify for range of day/month/year to make sure there are no typo or mistakes*/
					System.out.print("Enter birth date DDMMYYYY:");
					String birthDateString = in.next();
					day = Integer.parseInt(birthDateString.substring(0, 2));
					month = Integer.parseInt(birthDateString.substring(2, 4));
					year = Integer.parseInt(birthDateString.substring(4));
					GregorianCalendar cl = new GregorianCalendar(year, month - 1, 1);
					//verify the year in range 1900-2018
					if(year<1900 || year >2018) {
						isValidDate = false;
						System.out.println("Year out of range.Please enter correct birth date again!");
					}//verify the month in 1-12 range
					else if(month<1 || month>12) {
						isValidDate=false;
						System.out.println("Month out of range.Please enter correct birth date again!");
					}//verify day range of the month user entered
					else if(day < cl.getActualMinimum(Calendar.DAY_OF_MONTH)
							|| day > cl.getActualMaximum(Calendar.DAY_OF_MONTH)) {
						isValidDate=false;
						System.out.println("Day out of range.Please enter correct birth date again!");
					}
					else {isValidDate=true;}


				}while(!isValidDate);



				//menu options for types of patient
				System.out.println("Enter the type of patient:");
				System.out.println("1. Maternity Patient");
				System.out.println("2. OutPatient");
				System.out.println("3. Regular Patient");
				int type=in.nextInt();
				//calling method to add all collecting data into the ArrayList
				clinic.addPatient(lName, fName, hCard, new OurDate(day,month,year), type);

			}
		}

	}//end of addPatient() method


	public void addAppointment() {
		boolean isDateTaken=false;
		boolean isValidDate= true;
		int choice, day, month, year;
		//verify the number of appointments
		if (clinic.getNumberAppointments() == clinic.getMaxAppointments()) {
			System.out.println("Max appointments reached, please come back tommorow.");
			return;
		}
		//if not go ahead continue the data input process	
		else {

			System.out.print("Enter health card number:");

			int healthCardNumber = in.nextInt();

			int bookingPatient=0;

			/*Verify if patient already in system. if found patient, keep booking appointment, otherwise
			 * return to the menu to create patient first. */
			boolean isFound = false;
			for(int i=0; i<clinic.getPatients().size();i++ ) {
				if(healthCardNumber-clinic.getPatients().get(i).getHealthCardNumber()==0) {
					System.out.println(clinic.getPatients().get(i));
					bookingPatient=i;
					isFound = true;
				}
			}		
			if(!isFound) {
				System.out.println("Patient no in file,please go to 1 add patient first");
				return;
			}
			System.out.println();
			//list all Doctors 
			printDoctors();

			boolean isDoctorTaken=false;
			//list doctors by names
			do {
				//select the doctor 
				System.out.print("Enter number for doctor selection:");
				choice=in.nextInt();
				//verify chosen doctor if already taken
				for(int i =0; i<clinic.getAppointments().size();i++) {
					if(clinic.getDoctors().get(choice-1).getFirstName()==clinic.getAppointments().get(i).getDoctor().getFirstName() 
							&& clinic.getDoctors().get(choice-1).getLastName()==clinic.getAppointments().get(i).getDoctor().getLastName() ) {
						isDoctorTaken=true;
					}else {
						isDoctorTaken=false;
					}
				}
				if(isDoctorTaken) {
					System.out.println("Doctor already taken,please choose another doctor for your appointment.");
				}
			}while(isDoctorTaken);	


			do{


				do {
					/*verify the date entry in the proper ranges for day/month/year*/
					System.out.print("Enter desired appointment date DDMMYYYY:");
					String appDateString = in.next();
					day = Integer.parseInt(appDateString.substring(0, 2));
					month = Integer.parseInt(appDateString.substring(2, 4));
					year = Integer.parseInt(appDateString.substring(4));

					GregorianCalendar cl = new GregorianCalendar(year, month - 1, 1);
					//verify the year in range 1900-2018
					if(year<1900 || year >2018) {
						isValidDate=false;
						System.out.println("Year out of range.Please enter correct date again!");
					}//verify the month in 1-12 range
					else if(month<1 || month>12) {
						isValidDate=false;
						System.out.println("Month out of range.Please enter correct date again!");
					}//verify day range of the month user entered
					else if(day < cl.getActualMinimum(Calendar.DAY_OF_MONTH)
							|| day > cl.getActualMaximum(Calendar.DAY_OF_MONTH)) {
						isValidDate=false;
						System.out.println("Day out of range.Please enter correct date again!");
					}
					else {isValidDate=true;}


				}while(!isValidDate);

				/*Verify if appointment date for patient is taken already*/
				for(int i=0;i<clinic.getAppointments().size();i++) {
					if(day==clinic.getAppointments().get(i).getAppointmentDate().getDay()
							&& month==clinic.getAppointments().get(i).getAppointmentDate().getMonth()
							&& year==clinic.getAppointments().get(i).getAppointmentDate().getYear()) {

						isDateTaken=true;
					}else {
						isDateTaken=false;
					}			
				}
				if(isDateTaken) {
					System.out.println("Doctor already has an appointment that day.");
				}
			}while(isDateTaken);

			clinic.addAppointment(clinic.getPatients().get(bookingPatient),clinic.getDoctors().get(choice-1), new OurDate(day,month,year));

		}


	}

	public void cancelAppointment() {

		int cancelPatientIndex=0;
		boolean isFound=false;
		boolean isValidDate=false;
		int day=0,month=0,year=0;
		if(clinic.getAppointments().isEmpty()) {
			System.out.println("There are no appointments to cancel");
			return;
		}
		else {

			System.out.print("Enter health card number: ");
			int hCard = in.nextInt();
			for(int i=0; i<clinic.getPatients().size();i++ ) {
				if(hCard-clinic.getPatients().get(i).getHealthCardNumber()==0) {
					System.out.println(clinic.getPatients().get(i));
					cancelPatientIndex=i;
					isFound = true;
				}
			}		
			if(!isFound) {
				System.out.println("Patient no in file");
				return;
			}

			printDoctors();
			System.out.print("Enter number for doctor selection: ");
			int choice = in.nextInt();
			in.nextLine();

			do {

				/*Verify for range of day/month/year to make sure there are no typo or mistakes*/
				System.out.print("Enter appointment date DDMMYYYY: ");
				String appointmentDate = in.next();
				day = Integer.parseInt(appointmentDate.substring(0, 2));
				month = Integer.parseInt(appointmentDate.substring(2, 4));
				year = Integer.parseInt(appointmentDate.substring(4));
				GregorianCalendar cl = new GregorianCalendar(year, month - 1, 1);
				//verify the year in range 1900-2018
				if(year<1900 || year >2018) {
					isValidDate = false;
					System.out.println("Year out of range.Please enter correct birth date again!");
				}//verify the month in 1-12 range
				else if(month<1 || month>12) {
					isValidDate=false;
					System.out.println("Month out of range.Please enter correct birth date again!");
				}//verify day range of the month user entered
				else if(day < cl.getActualMinimum(Calendar.DAY_OF_MONTH)
						|| day > cl.getActualMaximum(Calendar.DAY_OF_MONTH)) {
					isValidDate=false;
					System.out.println("Day out of range.Please enter correct birth date again!");
				}
				else {isValidDate=true;}


			}while(!isValidDate);

			//compare if appointment in the ArrayList, if yes go ahead remove it
			for(int i=clinic.getAppointments().size()-1;i>=0;i--) {// for loop
				if(clinic.getAppointments().get(i).getPatient().equals(clinic.getPatients().get(cancelPatientIndex))
						&& clinic.getAppointments().get(i).getDoctor().equals(clinic.getDoctors().get(choice-1))
						&& clinic.getAppointments().get(i).getAppointmentDate().equals(new OurDate(day,month,year))) {

					clinic.cancelAppointment(i);	
					System.out.println("\nAppointment Cancelled");
					break;
				}

			}

		}

	}

	//printout appointments made if there is any
	public void listAppointment() {
		//verify if there is any appointments
		if (clinic.getNumberAppointments() == 0) {
			System.out.println("No appointments in the appointments list");
			return;
		}else {//if there are appoints, print them out
			for (int i = 0; i < clinic.getAppointments().size(); i++) {

				System.out.println(clinic.getAppointments().get(i).toString());
			}

		}

	}

	//print the doctors
	public void printDoctors() {

		for (int i = 0; i < clinic.getDoctors().size(); i++) {
			System.out.println((i+1)+" "+clinic.getDoctors().get(i));
		}
	}
	//print patient method 
	public void printPatient() {

		for (int i = 0; i < clinic.getPatients().size(); i++) {
			System.out.println(clinic.getPatients().get(i));
		}

	}


}//end of class
