package assign2;
/*
 * File Name:MaternityPatient.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/10/22
 */

//MaternityPatient Inheritance the parent Patient class
public class MaternityPatient extends Patient{

	//define two field variables
	private OurDate dueDate;
	private boolean nutritionTesting;

	/*
	 *default constructor of MaternityPatient class 
	 */
	public MaternityPatient() {
		//chain the constructor
		this("unknown","unknown", 1, new OurDate(), new OurDate(),false);

	}

	/*
	 *parameter constructor of MaternityPatient class 
	 */
	public MaternityPatient(String firstName, String lastName, int healthCardNumber, OurDate birthDate, OurDate dueDate,
			boolean nutritionTesting) {

		//INVOKE SETTERS AND SUPER CLASS INSTEAD OF ASSIGNING VALUES 
		super(firstName, lastName, healthCardNumber, birthDate);
		setDueDate(dueDate);
		setNutritionTesting(nutritionTesting);
	}

	/*
	 * getter of dueDate for OurDate class
	 */
	public OurDate getDueDate() {
		return dueDate;
	}

	/*
	 * setter of dueDate for OurDate class
	 */
	private void setDueDate(OurDate dueDate) {
		this.dueDate = dueDate;
	}

	/*
	 * getter of the boolean value for NutritionTesting
	 */
	public boolean getNutritionTesting() {
		return nutritionTesting;
	}

	/*
	 * setter of the boolean value for NutritionTesting
	 */
	private void setNutritionTesting(boolean nutritionTesting) {
		this.nutritionTesting = nutritionTesting;
	}

	/* 
	 * toString() override for the MaternityPatient class
	 */
	@Override
	public String toString() {
		return super.toString()+" dueDate: " + dueDate + ", nutritionTesting: " + nutritionTesting;
	}


	/* 
	 * hashCode() override for the MaternityPatient class
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((dueDate == null) ? 0 : dueDate.hashCode());
		result = prime * result + (nutritionTesting ? 1231 : 1237);
		return result;
	}

	/*
	 * equals() override for MaternityPatient class
	 */
	@Override
	public boolean equals(Object obj) {
		if(obj == null)
			return false;
		if(!(obj instanceof MaternityPatient))
			return false;
		MaternityPatient mp = (MaternityPatient) obj;
		return super.equals(mp) && this.getNutritionTesting()==mp.getNutritionTesting() && this.getDueDate().equals(mp.getDueDate());

	}	

}
