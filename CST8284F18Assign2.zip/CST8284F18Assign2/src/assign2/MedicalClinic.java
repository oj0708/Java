package assign2;
/*
 * File Name:MedicalClinic.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/10/22
 */

import java.util.ArrayList;


public class MedicalClinic {

	/*
	 * define three ArrayLists for Appointment/Patient/Doctor
	 */
	private ArrayList<Appointment> appointments; 
	private ArrayList<Patient> patients;
	private ArrayList<Doctor> doctors;

	/*
	 * define counters for appointments/doctors/patients
	 */
	private static int numberAppointments;
	private static int numberPatients;
	private static int numberDoctors;

	/*
	 * set counters' Max limits for appointments/doctors/patients
	 */
	private static final int MAX_APPOINTMENTS = 5;
	private static final int MAX_DOCTORS = 5;
	private static final int MAX_PATIENTS = 5;



	/*
	 * default constructor for MedicalClinic Class
	 */
	public MedicalClinic() {
		//initialize the three ArrayList appointments/patients/doctors
		appointments = new ArrayList<Appointment>();
		patients = new ArrayList<Patient>();
		doctors = new ArrayList<Doctor>();
		//set all counters to 0
		numberAppointments=0;
		numberPatients=0;
		numberDoctors=0;

		/*some random data to create those five doctors to make this work*/
		doctors.add(0, new Doctor("Singh", "Vikash","endocrinologist"));
		doctors.add(1, new Doctor("Miller", "Susan","cardiologist"));
		doctors.add(2, new Doctor("Do", "Thanh","neurologist"));
		doctors.add(3, new Doctor("DaSilva", "Francois","internist"));
		doctors.add(4, new Doctor("Chin", "Judy","Family Physican"));

		//set numberDoctors to MAX
		numberDoctors=MAX_DOCTORS;
	}
	/*
	 *  Adding new patients to the system until MAX patients reached.
	 */
	public void addPatient(String lastName, String firstName, int healthCardNumber, OurDate date, int patientType) {


		switch(patientType) {

		case 1:
			patients.add(new MaternityPatient(firstName,lastName,healthCardNumber,date,new OurDate(),false));
			break;

		case 2:
			patients.add(new OutPatient(firstName,lastName,healthCardNumber,date,-1.0,false));
			break;

		case 3:
			patients.add(new Patient(firstName,lastName,healthCardNumber,date));
			break;
		}
		numberPatients ++;//patient counter +1

	}
	/*
	 *  Making appointments for existing patients until MAX appointments reached.
	 */
	public void addAppointment(Patient patient, Doctor doctor, OurDate date) {

		appointments.add(new Appointment(patient, doctor, date));

		numberAppointments ++;//appointments counter +1
	}
	/*
	 * Appointments Cancellation option used .remove(index), 
	 * also Verified the existing status of the appointment before it got removed.
	 */
	public void cancelAppointment(int index) {

		appointments.remove(index);
		numberAppointments --;//appointments counter -1
		

	}

	/*
	 * getter for the ArrayList appointments
	 */
	public ArrayList<Appointment> getAppointments() {
		return appointments;
	}
	/*
	 * getter for the ArrayList patients
	 */
	public ArrayList<Patient> getPatients() {
		return patients;
	}
	/*
	 * getter for the ArrayList doctors
	 */
	public ArrayList<Doctor> getDoctors() {
		return doctors;
	}
	/*
	 * getter for the numberAppointments
	 */
	public  int getNumberAppointments() {
		return numberAppointments;
	}
	/*
	 * getter for the numberPatients
	 */
	public int getNumberPatients() {
		return numberPatients;
	}
	/*
	 * getter for the numberDoctors
	 */
	public int getNumberDoctors() {
		return numberDoctors;
	}
	/*
	 * getter for the mAX_APPOINTMENTS
	 */
	public int getMaxAppointments() {
		return MAX_APPOINTMENTS;
	}
	/*
	 * getter for the mAX_DOCTORS
	 */
	public int getMaxDoctors() {
		return MAX_DOCTORS;
	}
	/*
	 * getter for  the mAX_PATIENTS
	 */
	public int getMaxPatients() {
		return MAX_PATIENTS;
	}


}//end of class
