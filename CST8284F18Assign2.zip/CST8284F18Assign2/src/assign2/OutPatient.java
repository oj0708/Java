package assign2;
/*
 * File Name:OutPatient.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/10/22
 */

//OutPatient Inheritance the parent Patient class
public class OutPatient extends Patient {

	//field variables
	private double distanceFromClinic;
	private boolean mobility;



	/*
	 *default constructor 
	 */
	public OutPatient() {
		//chain constructor
		this("unknown", "unknown", 1, new OurDate(), 1.0,false);
	}

	/*
	 * parameter constructor
	 */
	public OutPatient(String firstName, String lastName, int healthCardNumber, OurDate birthDate,
			double distanceFromClinic, boolean mobility) {
		//INVOKE SETTERS AND SUPER CLASS INSTEAD OF ASSIGNING VALUES 
		super(firstName, lastName, healthCardNumber, birthDate);
		setDistanceFromClinic(distanceFromClinic);
		setMobility(mobility);
	}

	/*
	 * getter of distanceFromClinic
	 */
	public double getDistanceFromClinic() {
		return distanceFromClinic;
	}

	/*
	 * setter of distanceFromClinic
	 */
	private void setDistanceFromClinic(double distanceFromClinic) {
		this.distanceFromClinic = distanceFromClinic;
	}

	/*
	 * getter of mobility
	 */
	public boolean getMobility() {
		return mobility;
	}

	/*
	 * setter of mobility
	 */
	private void setMobility(boolean mobility) {
		this.mobility = mobility;
	}

	/*
	 * hashCode() override for OutPatient class 
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		long temp;
		temp = Double.doubleToLongBits(distanceFromClinic);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + (mobility ? 1231 : 1237);
		return result;
	}

	/* 
	 * equals() override for the OutPatient class
	 */
	@Override
	public boolean equals(Object obj) {

		if(obj == null)
			return false;
		if(!(obj instanceof OutPatient))
			return false;
		OutPatient op = (OutPatient) obj;
		return super.equals(op) && this.getDistanceFromClinic()==op.getDistanceFromClinic() && this.getMobility()==op.getMobility();
	}


}//end of class
