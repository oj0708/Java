package assign2test;
/*
 * File Name:PatientTester.java
 * Course Name:CST8284_Object Oriented Programming (Java)
 * Lab Section:314
 * Professors:CAROLYN MACISAAC & DAVID B HOUTMAN
 * Student Name: Qiang Pan
 * Student #: 040920667
 * Date:2018/10/22
 */

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import assign2.MaternityPatient;
import assign2.OurDate;
import assign2.OutPatient;
import assign2.Patient;

class PatientTester {

	//define 4 Patient objects for testing
	Patient patient1,patient2,patient3,patient4;
	
	//before all test print message
	@BeforeAll
	public static void setUpBeforeAllTests() {
		System.out.println("Test create by Qiang Pan for Assignment2.\nTest starting now");
	}
	
	//after all test print message
	@AfterAll
	public static void tearDownAfterAllTests() {
		System.out.println("Test done!");
	}
	// before each test	 
	
	//Initialize the 4 Patient objects before every test 
	@BeforeEach
	public void setUpBeforeEachTest(){

		patient1 = new MaternityPatient("Josh", "Brolin", 874521, new OurDate(12, 04, 1987),new OurDate(10,27,2018),true);
		patient2 = new MaternityPatient("Josh", "Brolin", 874521, new OurDate(12, 04, 1987),new OurDate(10,27,2018),true);
		patient3 = new OutPatient("Brack", "Dunstd", 6532147, new OurDate(12, 25, 2007),33.0,true);
		patient4 = new OutPatient("Brack", "Dunstd", 6532147, new OurDate(12, 25, 2007),33.0,true);
	}
	
	/*
	 * clean after each test  finished
	 */

	@AfterEach
	void tearDownAfterEachTest(){
		patient1 = null;
		patient2 = null;
		patient3 = null;
		patient4 = null;
		
	}
	/*
	 *Test for subclass equals for true
	 */
	@Test
	public void testSubClassEqualsForTrue() {

		System.out.println("testing for subClassEqualsForTrue");
		assertTrue("failure - not same",patient1.equals(patient2));
		assertTrue("failure - not same",patient3.equals(patient4));

	}
	/*
	 * Test for subclass equals for false
	 */
	@Test
	public void testSubClassEqualsForfalse() {
		patient2 = new MaternityPatient("Qiang", "Pan", 874521, new OurDate(12, 04, 1987),new OurDate(10,27,2018),false);
		patient4 = new OutPatient("Qiang", "Pan", 6532147, new OurDate(12, 25, 2007),33.0,false);
		System.out.println("testing for subClassEqualsForfalse");
		assertFalse("failure - should be false",patient1.equals(patient3));
		assertFalse("failure - should be false",patient2.equals(patient4));
	}
}//end of class

