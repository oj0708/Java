package cst8284f18lab4;

public class OurDate {

	private int day;
	private int month;
	private int year;

	public OurDate() {

		// TODO: CHAIN THE CONSTRUCTOR
		//ASSIGN DEFAULT VALUES OF 1/1/1800
		this(1,1,1800);
		//	    this.day = 10;
		//		this.month = 9;
		//		this.year = 2018;
	}

	public OurDate(int day, int month, int year) {

		//TO DO:  INSTEAD OF STATEMENTS LIKE this.day = day, ASSIGN VALUES TO FIELDS BY INVOKING SETTERS
		setDay(day);
		//		this.day = day;
		setMonth(month);
		//		this.month = month;
		setYear(year);
		//		this.year = year;
	}

	//TO DO:  USE THE "Source" DROP-DOWN MENU FROM THE ECLIPSE IDE AND SELECT "Generate hashCode() and equals()..."
	//TO DO:  DELETE THE SOURCE CODE IN THE equals() METHOD.  WRITE YOUR OWN CODE TO DETERMINE IF TWO DATES ARE EQUAL
	//NO NEED TO MODIFY THE hashCode() method
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + day;
		result = prime * result + month;
		result = prime * result + year;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
				if (this == obj)
					return true;
				if (obj == null)
					return false;
				if (getClass() != obj.getClass())
					return false;
		OurDate other = (OurDate) obj;
		if (this.day != other.day && this.month != other.month && this.year != other.year)
			return false;
		
		return true;
	}

	//TO DO:  MODIFY THE STRING AFTER THE return STATEMENT SUCH THAT THE OUTPUT MATCHES THE SAMPLE PROGRAM OUTPUT IN THE LAB WRITEUP
	@Override
	public String toString() {
		return getDay()+"/"+getMonth()+"/"+getYear();
		//		return "OurDate [day=" + day + ", month=" + month + ", year=" + year + "]";
	}

	//TO DO:  CHANGE ACCESS SPECIFIER FROM public TO private, making references immutable from an outside class
	private void setDay(int day) {

		// IN FUTURE LABS/ASSIGNMENTS, DATA VERIFICATION WILL BE DONE HERE, BEFORE this.day = day;
		this.day = day;
	}

	public int getDay() {
		return day;
	}

	//TO DO:  CHANGE ACCESS SPECIFIER FROM public TO private
	private  void setMonth(int month) {

		// IN FUTURE LABS/ASSIGNMENTS, DATA VERIFICATION WILL BE DONE HERE, BEFORE this.month = month;
		this.month = month;
	}

	public int getMonth() {
		return month;
	}

	//TO DO:  CHANGE ACCESS SPECIFIER FROM public TO private
	private  void setYear(int year) {

		// IN FUTURE LABS/ASSIGNMENTS, DATA VERIFICATION WILL BE DONE HERE, BEFORE this.year = year;
		this.year = year;
	}

	public int getYear() {
		return year;
	}



}//END CLASS OURDATE