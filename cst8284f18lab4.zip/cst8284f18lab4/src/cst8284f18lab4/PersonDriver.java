package cst8284f18lab4;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class PersonDriver {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		final int MAX = 5;
		Person [] persons = new Person[MAX];
		persons[0] = new Person();
		persons[1] = new Person("Justin Trudeau");
		persons[2] = new Person(54321);
		persons[3] = new Person(new OurDate(6, 10, 2018));
		persons[4] = new Person("Lao Chee", 421, new OurDate(22, 12, 1958));
		
//		TO DO:  PRINT OUT ALL OF THE ARRAY ELEMENTS USING A FOR LOOP
		System.out.println("ENTIRE ARRAY USING REGULAR FOR LOOP: ");
	
		for(int i = 0; i < persons.length; i++) {
			
			System.out.println(persons[i]);
		}
		
//              TO DO:  REFACTOR THE ARRAY CODE AND MAKE AN EQUIVALENT ArrayList
//              DECLARE A new ArrayList<Person> and call it  'people'
			ArrayList<Person> people=new ArrayList<Person>();
		
//		TO DO:  ADD THE ARRAY ELEMENTS TO THE ArrayList - THERE ARE A VARIETY OF WAYS TO DO THIS BUT YOU MUST USE THE add() method
			for(int i = 0; i < persons.length; i++) {

				people.add(persons[i]);
			}
			
//		TO DO:  PRINT OUT ONLY THE 4TH (i.e.  THE 3rd ELEMENT INDEXED) ArrayList ELEMENT - USE THE get() METHOD
		System.out.println("A SINGLE ARRAYLIST ELEMENT:\n ");
		System.out.println(people.get(3));
		
//		TO DO:  PRINT OUT ALL OF THE ArrayList ELEMENTS USING A FOR LOOP.
//		ARE YOU ITERATING UNTIL people.length OR people.size() ???
//		ARE YOU ACCESSING EACH ArrayList ELEMENT WITH THE LOOP INDEX i ???
//		INVOKE THE get() AND THE toString() METHOD IN A System.out.println()
		System.out.println("ENTIRE ARRAYLIST USING REGULAR FOR LOOP:");
		for (int i = 0; i < people.size(); i++) {
			System.out.println(people.get(i).toString());
		}
		
//		TO DO:  ADD ANOTHER ELEMENT TO THE ArrayList AT RUNTIME:
//		USE Person and OurDate CONSTRUCTORS THAT SPECIFIES ALL FIELDS, PROMPT USER FOR INFO.
		System.out.println("ADD AN ELEMENT TO THE ARRAYLIST - DATA COLLECTED FROM USER:");
		System.out.print("NAME:");
		String name = in.nextLine();
		System.out.print("HEALTH CARD NUMBER:");
		int id = in.nextInt();
		System.out.print("BIRTHDATE DDMMYYYY:");
		String birthDate = in.next();
		in.nextLine();
		people.add(new Person(name,id, new OurDate(Integer.parseInt(birthDate.substring(0, 2)),Integer.parseInt(birthDate.substring(2, 4)),Integer.parseInt(birthDate.substring(4)))));
		// ArrayList you can add an extra element at runtime.  An array has a maximum size that is specified at compile time.  An ArrayList ca
//		TO DO:  REMOVE Person [name=unknown, idNum=-9, birthdate=OurDate [day=6, month=10, year=2018]]
	
		people.remove(3);
//		TO DO:  VERIFY ArrayList ELEMENT WAS REMOVED AND NEW PERSON ADDED:
//		PRINT OUT ALL OF THE ArrayList ELEMENTS USING AN ENHANCED FOR LOOP
		System.out.println("\nVERIFY NEW ARRAY LIST ELEMENT WAS ADDED, AND THE ELEMENT FROM THE PREVIOUS STEP WAS REMOVED - PRINT ENTIRE ARRAYLIST USING ENHANCED FOR LOOP:");	
		for(Person element:people) {
			System.out.print("\n"+element);
		}
		
		
//     TO DO:  SEARCH THE ArrayList FOR A Person
//     PROMPT USER FOR A NAME, USE A LOOP
		System.out.print("ENTER A NAME TO SEARCH FOR: ");
		String search = in.nextLine();
	
		for(int i =0;i<people.size();i++) {
			
			if(people.get(i).getName().toLowerCase().equals(search.toLowerCase())){
				
				System.out.println("\n"+search+" IS FOUND IN ARRAY POSITION "+i);
			}
		}
		
		in.close();
//     TO DO:  ONLY COMMENTING AND UNCOMMENTING AND THEN RUN THE CODE IS REQUIRED - NO CODING CHANGES REQUIRED		
//     TO DO:  SORT ArrayList BY NAME - HINT:  SEE PAGE 697 OF DEITEL TEXTBOOK
//     TO DO:  UNCOMMENT THE FOLLOWING LINES OF CODE THAT ATTEMPT TO INVOKE THE sort() METHOD
//     HINT:  ONLY ONE OF THEM WORKS.
		//people.sort(); 
		//Collections.sort(people);
		//Collections.sort((List)people); 
		//Collections.sort(people,  new NameComparator<Person>());
		Collections.sort(people,  new NameComparator() );
					
		System.out.println("\nVERIFY ARRAY LIST IS SORTED BY NAME  - PRINT ENTIRE ARRAY LIST:\n ");	
		
		//TO DO:  COMMENT AND UNCOMMENT THE LINE OR LINES OF CODE TO VERIFY CORRECT CONSOLE OUTPUT
		//System.out.println(people); 
		
		//TO DO:  COMMENT AND UNCOMMENT THE LINE OR LINES OF CODE TO VERIFY CORRECT CONSOLE OUTPUT
		//System.out.println(people.toString()); 
		
		//TO DO:  COMMENT AND UNCOMMENT THE LINE OR LINES OF CODE TO VERIFY CORRECT CONSOLE OUTPUT
		for(Person p: people) 
			System.out.println(p.toString());
	}
	
	//PRIVATE INNER CLASS - THIS MARKS THE BEGINNING OF UNDERSTANDING OF SYNTAX FOR ANONYMOUS INNER CLASSES, EVENT HANDLING, AND LAMBDAS
	//GO TO THE bin FOLDER FOR THE PROJECT AND NOTE THE EXTENSION FOR PersonDriver
	//implements IS THE KEYWORD FOR INTERFACES, IN THE SAME WAY THAT extends IS THE KEYWORK FOR INHERITANCE
	private static class NameComparator implements Comparator<Person> {
	
		@Override
		public int compare(Person o1, Person o2) { //MUST PROVIDE compare() METHOD BY VIRTUE OF IMPLEMENTING Comparator INTERFACE
	
			if(o1.getName().compareTo(o2.getName()) > 1)
				return 1;
			else if(o1.getName().compareTo(o2.getName()) < 1)
				return -1;
			else
				return 0;
			
			//return (o1.getName()).compareTo(o2.getName());// compareTo() BEHAVES SIMILAR TO A 'CALLBACK' METHOD - THE UNDERLYING LOWER LEVEL CODE IS AUTOMATICALLY INVOKED
	
		}	
	} //End inner private class

} //End class PersonDriver