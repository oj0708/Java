package cst8284f18lab4;

public class Person {

	private String name; 
	private int idNum;
	private OurDate birthdate ;
	
	//TO DO FOR ALL CONSTRUCTORS REQUIRING DEFAULT INITIALZATIONS SET name TO "unknown"
	//TO DO FOR ALL CONSTRUCTORS REQUIRING DEFAULT INITIALZATIONS SET idNum TO -9
	//TO DO FOR ALL CONSTRUCTORS REQUIRING DEFAULT INITIALZATIONS SET birthdate TO new OurDate(), AND BY VIRTUE OF DEFAULT OurDate VALUES, January 1, 1800 
	
	public Person() {
		
		// TODO CHAIN THE CONSTRUCTOR:  SEE DEITEL CHAPTER 8
	this("unknown",-9,new OurDate(1,1,1800));
//		this.name = null;
//		this.idNum = 0;
//		this.birthdate = null;
	}
	
	public Person(String name) {
		
		// TODO CHAIN THE CONSTRUCTOR
		this(name,-9,new OurDate(1,1,1800));
//		this.name = name;
//		this.idNum = 0;
//		this.birthdate = null;
	}
		
	public Person(int idNum) {
			
		// TODO CHAIN THE CONSTRUCTOR
		this("unknown",idNum,new OurDate(1,1,1800));
//		 this.name =null;
//			this.idNum = idNum;
//			this.birthdate = null; 
		}
	
	public Person(OurDate birthdate) {
		
		// TODO CHAIN THE CONSTRUCTOR
		this("unknown",-9,birthdate);
//		this.name = null;
//		this.idNum = 0;
//		this.birthdate = null;
	}
	
	public Person(String name, int idNum) {
		
		// TODO CHAIN THE CONSTRUCTOR
		this(name,idNum,new OurDate(1,1,1800));
//		this.name = name;
//		this.idNum = 0;
//		this.birthdate = null;
	}
	
	public Person(String name, OurDate birthdate) {
		
		// TODO CHAIN THE CONSTRUCTOR
		this(name,-9,birthdate);
//		this.name = name;
//		this.idNum = 0;
//		this.birthdate = birthdate;
	}
	
	public Person(int idNum, OurDate birthdate) {
		
		// TODO CHAIN THE CONSTRUCTOR
		this("unknown",idNum,birthdate);
//		this.name = null;
//		this.idNum = idNum;
//		this.birthdate = birthdate;
	}
	
     public Person(String name, int idNum, OurDate birthdate) {
			
			// TODO:  INVOKE SETTERS INSTEAD OF ASSIGNING VALUES USING this.name = name, etc...
			this.setName(name);
//			this.name = name;
			this.setIdNum(idNum);
//			this.idNum = idNum;
			this.setBirthdate(birthdate);
//			this.birthdate = birthdate;
		}
	
	
 //  TO DO:  MODIFY THE STRING AFTER THE return STATEMENT SUCH THAT THE OUTPUT MATCHES THE SAMPLE PROGRAM OUTPUT IN THE LAB WRITEUP
	 @Override
	 public String toString() {
		
		return "Name:"+name+"\nHealth Card Number:"+idNum+"\nDOB:"+birthdate+"\n";
	 }

	//TO DO:  USE THE "Source" DROP-DOWN MENU FROM THE ECLIPSE IDE AND SELECT "Generate hashCode() and equals()..."
		//TO DO:  DELETE THE SOURCE CODE IN THE equals() METHOD.  WRITE YOUR OWN CODE TO DETERMINE IF TWO Person REFERENCES ARE EQUAL
		//NO NEED TO MODIFY THE hashCode() method
	
		/* (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((birthdate == null) ? 0 : birthdate.hashCode());
			result = prime * result + idNum;
			result = prime * result + ((name == null) ? 0 : name.hashCode());
			return result;
		}

		/* (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Person other = (Person) obj;
			if (birthdate == null) {
				if (other.birthdate != null)
					return false;
			} else if (!birthdate.equals(other.birthdate))
				return false;
			if (idNum != other.idNum)
				return false;
			if (name == null) {
				if (other.name != null)
					return false;
			} else if (!name.equals(other.name))
				return false;
			return true;
		}
//			Person p = (Person)obj;
//			if(!name.equals(p.name)) {
//				return false;
//			}else {
//				return true;
//			}
//			
	
		
	
	public int getIdNum() {
		return idNum;
	}

	//TO DO:  CHANGE ACCESS SPECIFIER FROM public TO private
	private void setIdNum(int idNum) {
		
		// IN FUTURE LABS/ASSIGNMENTS, DATA VERIFICATION WILL BE DONE HERE, BEFORE this.day = day;
		this.idNum = idNum;
	}

	public OurDate getBirthdate() {
		return birthdate;
	}

	//TO DO:  CHANGE ACCESS SPECIFIER FROM public TO private
	private  void setBirthdate(OurDate birthdate) {
		
		// IN FUTURE LABS/ASSIGNMENTS, DATA VERIFICATION WILL BE DONE HERE, BEFORE this.day = day;
		this.birthdate = birthdate;
	}

	public String getName() {
		return this.name;
	}
	
	//TO DO:  CHANGE ACCESS SPECIFIER FROM public TO private
	private  void setName(String name) {
			
		// IN FUTURE LABS/ASSIGNMENTS, DATA VERIFICATION WILL BE DONE HERE, BEFORE this.day = day;
		this.name = name;
	}
	
	//TO DO:  CHANGE ACCESS SPECIFIER FROM public TO private
//	private  void setNumber(int number) {
//		
//		// IN FUTURE LABS/ASSIGNMENTS, DATA VERIFICATION WILL BE DONE HERE, BEFORE this.day = day;
//		this.idNum = number;
//	}
	
	public int getNumber() {
		return idNum;
	}


	
}//END CLASS